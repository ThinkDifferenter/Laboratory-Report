# vigenere_breaker
Tries to break an xor-vigenere cyphertext, guessing key length and the key values.
Right now, it supposes that the clear text contains only punctuation characters and letter. No characters such as "[]{}#etc"
