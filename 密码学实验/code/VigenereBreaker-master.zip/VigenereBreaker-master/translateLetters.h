/**************************
Project 1, CSCE 557
Author: Eric Reeves
Last Modified: 1/28/2016

Header file for translateLetters.cpp
*************************/



#ifndef  TRANSLATELETTERS_H
#define TRANSLATELETTERS_H



int letterLookup(char letter);
char numLookup(int num);



#endif  // TRANSLATELETTERS_H 